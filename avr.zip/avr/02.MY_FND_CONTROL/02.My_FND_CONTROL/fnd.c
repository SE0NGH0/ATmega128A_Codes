﻿/*
 * fnd.c
 *
 * Created: 2025-03-06 오후 12:22:24
 *  Author: microsoft
 */ 

#include "fnd.h"
#include "button.h"

void init_fnd(void);
extern void init_button(void);
extern int get_button(int button_num, int button_pin);
uint32_t ms_count = 0; // ms를 재는 count 변수 unsigned int --> uint32_t
uint32_t sec_count = 0; // 초를 재는 count 변수 unsigned int --> uint32_t
uint32_t dp_count = 0;

int button0_state = 0;
int button1_state = 0;

int fnd_main(void);
void fnd_display(void);
void circle(void);

int fnd_main(void)
{
	init_fnd();
	init_button();
	
	while(1)
	{
		if (get_button(BUTTON0, BUTTON0PIN))
		{
			button0_state = !button0_state;
		}
		if (get_button(BUTTON1, BUTTON1PIN))
		{
			button1_state = !button1_state;
			if(button1_state)
			{
				sec_count = 0;
				button1_state = 0;
			}
		}
		fnd_display();
		_delay_ms(1);
		ms_count++;
		if(ms_count >= 1000) // 1000ms --> 1s
		{
			ms_count = 0;
			dp_count = !dp_count;
			sec_count++;
		}
	}
	
	return 0;
}

void init_fnd(void)
{
	FND_DATA_DDR = 0xff; // 출력 모드로 설정
	// FND_DIGIT_DDR |= 0xf0; // 자릿수 선택 7654
	FND_DIGIT_DDR |= 1 << FND_DIGIT_D1 | 1 << FND_DIGIT_D2 | 1 << FND_DIGIT_D3 | 1 << FND_DIGIT_D4;
	
	// fnd를 all off
#if 1 // common cathode 방식
	FND_DATA_PORT = 0x00; // fnd를 all off
#else // common anode 방식
	FND_DATA_PORT = ~0x00; // fnd를 all off 0xff;
#endif
}

void fnd_display(void)
{
#if 1 // common cathode 방식
						  //  0      1      2      3      4      5      6      7      8      9      .
	uint8_t fnd_font[] = {~0xc0, ~0xf9, ~0xa4, ~0xb0, ~0x99, ~0x92, ~0x82, ~0xd8, ~0x80, ~0x90, ~0x7f};
		
	static uint8_t fnd_font10[] = {~0xff, ~0xff, ~0xfe, ~0xde, ~0xce, ~0xc6, ~0xc6, ~0xc6, ~0xc6};
	static uint8_t fnd_font1[] = {~0xff, ~0xfe, ~0xfe, ~0xfe, ~0xfe, ~0xfe, ~0xf6, ~0xf2, ~0xf0};
		
#else // common anode 방식
						 //  0     1     2     3     4     5     6     7     8     9     .
	uint8_t fnd_font[] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xd8, 0x80, 0x90, 0x7f};
#endif

	static int digit_select = 0; // static을 쓰면 전역 변수처럼 함수가 빠져 나갔다가 다시 들어오더라도 값을 유지
	
	switch(digit_select)
	{
		case 0: 
#if 1 // common cathode
			FND_DIGIT_PORT = ~(1 << FND_DIGIT_D4); // 01111111 FND_FIGIT_PORT = ~0x80
#else // common anode
			FND_DIGIT_PORT = 1 << FND_DIGIT_D4; // 10000000 FND_FIGIT_PORT = 0x80
#endif
			FND_DATA_PORT = fnd_font[sec_count % 10]; // 0~9초
			break;
		case 1: 
#if 1 // common cathode
			FND_DIGIT_PORT = ~(1 << FND_DIGIT_D3); // FND_FIGIT_PORT = ~0x40
#else // common anode
			FND_DIGIT_PORT = 1 << FND_DIGIT_D3; // FND_FIGIT_PORT = 0x40
#endif
			FND_DATA_PORT = fnd_font[sec_count / 10 % 6]; // 10단위초
			if(dp_count)
				FND_DATA_PORT |= fnd_font[10];
			else
				FND_DATA_PORT = fnd_font[sec_count / 10 % 6];
			break;
		case 2: 
#if 1 // common cathode
			FND_DIGIT_PORT = ~(1 << FND_DIGIT_D2); // FND_FIGIT_PORT = ~0x20
#else // common anode
			FND_DIGIT_PORT = 1 << FND_DIGIT_D2; // FND_FIGIT_PORT = 0x20
#endif
			if(button0_state)
				FND_DATA_PORT = fnd_font1[sec_count % 9];
			else
				FND_DATA_PORT = fnd_font[sec_count / 60 % 10]; // 1단위 분
			break;
		case 3: 
#if 1 // common cathode
			FND_DIGIT_PORT = ~(1 << FND_DIGIT_D1); // FND_FIGIT_PORT = ~0x10
#else // common anode
			FND_DIGIT_PORT = 1 << FND_DIGIT_D1; // FND_FIGIT_PORT = 0x10
#endif
			if(button0_state)
				FND_DATA_PORT = fnd_font10[sec_count % 9];
			else
				FND_DATA_PORT = fnd_font[sec_count / 600 % 6]; // 10단위 분
			break;
	}
	digit_select++;
	digit_select %= 4; // 다음 표시할 자릿수 선택
}
