﻿/*
 * fnd.c
 *
 * Created: 2025-03-06 오후 12:23:41
 *  Author: microsoft
 */ 
#include "fnd.h"
#include "extern.h"

void init_fnd(void);
void fnd_forward_display(void);
void fnd_backward_display(void);
void fnd_left_display(void);
void fnd_right_display(void);

void init_fnd(void)
{
	FND_DATA_DDR = 0xff;		// 출력 모드로 설정
	FND_DIGIT_DDR |= 1 << FND_DIGIT_D1 | 1 << FND_DIGIT_D2 | 1 << FND_DIGIT_D3 | 1 << FND_DIGIT_D4;
	FND_DIGIT_PORT = ~0x00;     // fnd를 all off  0xff;
}

void fnd_forward_display(void)
{
	uint8_t fnd_font0[] = {0xff, 0xff, 0xff, 0xfe, 0xfc, 0xf8, 0xf0, 0xf0};
	uint8_t fnd_font1[] = {0xef, 0xcf, 0xce, 0xce, 0xce, 0xce, 0xce, 0xc6};
	uint8_t fnd_font2[] = {0xfb, 0xf9, 0xf8, 0xf8, 0xf8, 0xf8, 0xf8, 0xf0};
	uint8_t fnd_font3[] = {0xff, 0xff, 0xff, 0xfe, 0xde, 0xce, 0xc6, 0xc6};

	static int digit_select=0;
	
	switch(digit_select)
	{
		case 0:
		FND_DIGIT_PORT = 0x80;
		FND_DATA_PORT = fnd_font0[sec_count % 8];
		break;
		case 1:
		FND_DIGIT_PORT = 0x40;
		FND_DATA_PORT = fnd_font1[sec_count % 8];
		break;
		case 2:
		FND_DIGIT_PORT =  0x20;
		FND_DATA_PORT = fnd_font2[sec_count % 8];
		break;
		case 3:
		FND_DIGIT_PORT = 0x10;
		FND_DATA_PORT = fnd_font3[sec_count % 8];
		break;
	}
	digit_select++;
	digit_select %= 4;
}

void fnd_backward_display(void)
{
	uint8_t fnd_font0[] = {0xff, 0x00};
	uint8_t fnd_font1[] = {0xff, 0x00};
	uint8_t fnd_font2[] = {0xff, 0x00};
	uint8_t fnd_font3[] = {0xff, 0x00};

	static int digit_select=0;
	
	switch(digit_select)
	{
		case 0:
		FND_DIGIT_PORT = 0x80;
		FND_DATA_PORT = fnd_font0[sec_count % 2];
		break;
		case 1:
		FND_DIGIT_PORT = 0x40;
		FND_DATA_PORT = fnd_font1[sec_count % 2];
		break;
		case 2:
		FND_DIGIT_PORT =  0x20;
		FND_DATA_PORT = fnd_font2[sec_count % 2];
		break;
		case 3:
		FND_DIGIT_PORT = 0x10;
		FND_DATA_PORT = fnd_font3[sec_count % 2];
		break;
	}
	digit_select++;
	digit_select %= 4;
}

void fnd_left_display(void)
{
	uint8_t fnd_font2[] = {0xfb, 0xf9, 0xf8, 0xf8, 0xf8, 0xf8, 0xf8, 0xf0};
	uint8_t fnd_font3[] = {0xff, 0xff, 0xff, 0xfe, 0xde, 0xce, 0xc6, 0xc6};

	static int digit_select=0;
	
	switch(digit_select)
	{
		case 0:
		FND_DIGIT_PORT = 0x80;
		FND_DATA_PORT = 0xff;
		break;
		case 1:
		FND_DIGIT_PORT = 0x40;
		FND_DATA_PORT = 0xff;
		break;
		case 2:
		FND_DIGIT_PORT =  0x20;
		FND_DATA_PORT = fnd_font2[sec_count % 8];
		break;
		case 3:
		FND_DIGIT_PORT = 0x10;
		FND_DATA_PORT = fnd_font3[sec_count % 8];
		break;
	}
	digit_select++;
	digit_select %= 4;
}

void fnd_right_display(void)
{
	uint8_t fnd_font0[] = {0xff, 0xff, 0xff, 0xfe, 0xfc, 0xf8, 0xf0, 0xf0};
	uint8_t fnd_font1[] = {0xef, 0xcf, 0xce, 0xce, 0xce, 0xce, 0xce, 0xc6};

	static int digit_select=0;
	
	switch(digit_select)
	{
		case 0:
		FND_DIGIT_PORT = 0x80;
		FND_DATA_PORT = fnd_font0[sec_count % 8];
		break;
		case 1:
		FND_DIGIT_PORT = 0x40;
		FND_DATA_PORT = fnd_font1[sec_count % 8];
		break;
		case 2:
		FND_DIGIT_PORT =  0x20;
		FND_DATA_PORT = 0xff;
		break;
		case 3:
		FND_DIGIT_PORT = 0x10;
		FND_DATA_PORT = 0xff;
		break;
	}
	digit_select++;
	digit_select %= 4;
}
