﻿/*
 * pwm.h
 *
 * Created: 2025-03-13 오후 12:48:40
 *  Author: microsoft
 */ 


#ifndef PWM_H_
#define PWM_H_
#define  F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h>

#define MOTOR_PWM_DDR DDRB
#define MOTOR_LEFT_PORT_DDR 5 // OC1A
#define MOTOR_RIGHT_PORT_DDR 6 // OC1B

#define MOTOR_DRIVER_DIRECTION_PORT PORTF
#define MOTOR_DRIVER_DIRECTION_DDR DDRF

#include "button.h"

#endif /* PWM_H_ */