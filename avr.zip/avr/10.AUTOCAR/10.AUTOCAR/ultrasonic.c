﻿/*
 * ultrasonic.c
 *
 * Created: 2025-03-12 오후 2:49:18
 *  Author: microsoft
 */ 

#include "ultrasonic.h"
#include "extern.h"
#include "def.h"

void init_ultrasonic(void);
void ultrasonic_trigger(void);
//void ultrasonic_trigger_front(void);
//void ultrasonic_trigger_right(void);
void distance_check(void);

volatile uint8_t scm_L[20];
volatile uint8_t scm_M[20];
volatile uint8_t scm_R[20];


volatile int ultrasonic_left_distance = 0;
volatile int ultrasonic_front_distance = 0;
volatile int ultrasonic_right_distance = 0;

ISR(INT4_vect) // LEFT
{
	// 1. 상승 edge
	if (ECHO_PIN_LEFT & (1 << ECHO_LEFT))
	{
		TCNT2 = 0;
	}
	// 2. 하강 edge
	else
	{
		// ECHO 핀에 들어온 펄스 길이를 us로 환산
		ultrasonic_left_distance = (1000000.0 * TCNT2 * 128 / F_CPU) / 58;
		// ultrasonic_left_distance = TCNT2;
		
		sprintf(scm_L,"dis_L= %dcm", ultrasonic_left_distance);
		
		// 예) TCNT1에 10이 들어 있다고 가정하자
		// 15.625khz의 1주기가 64us이다.
		// 64us * 10 == 640us
		// 640us / 58us (58us는 초음파 센서에서 1cm이동하는데 58us가 소요됨). ==> 11cm
		// sprintf(scm, "dis : %dcm\n", ultrasonic_distance / 58); // sprintf는 버퍼에 찍는 것
	}
}

ISR(INT5_vect) // LEFT
{
	// 1. 상승 edge
	if (ECHO_PIN_FRONT & (1 << ECHO_FRONT))
	{
		TCNT2 = 0;
	}
	// 2. 하강 edge
	else
	{
		// ECHO 핀에 들어온 펄스 길이를 us로 환산
		ultrasonic_front_distance = (1000000.0 * TCNT2 * 128 / F_CPU) / 58;
		// ultrasonic_front_distance = TCNT2;
		
		sprintf(scm_M,"dis_M= %dcm", ultrasonic_front_distance);

		
		// 예) TCNT1에 10이 들어 있다고 가정하자
		// 15.625khz의 1주기가 64us이다.
		// 64us * 10 == 640us
		// 640us / 58us (58us는 초음파 센서에서 1cm이동하는데 58us가 소요됨). ==> 11cm
		// sprintf(scm, "dis : %dcm\n", ultrasonic_distance / 58); // sprintf는 버퍼에 찍는 것
	}
}

ISR(INT6_vect) // LEFT
{
	// 1. 상승 edge
	if (ECHO_PIN_RIGHT & (1 << ECHO_RIGHT))
	{
		TCNT2 = 0;
	}
	// 2. 하강 edge
	else
	{
		// ECHO 핀에 들어온 펄스 길이를 us로 환산
		ultrasonic_right_distance = (1000000.0 * TCNT2 * 128 / F_CPU) / 58;
		// ultrasonic_right_distance = TCNT2;
		
		sprintf(scm_R,"dis_R= %dcm", ultrasonic_right_distance);

		
		// 예) TCNT1에 10이 들어 있다고 가정하자
		// 15.625khz의 1주기가 64us이다.
		// 64us * 10 == 640us
		// 640us / 58us (58us는 초음파 센서에서 1cm이동하는데 58us가 소요됨). ==> 11cm
		// sprintf(scm, "dis : %dcm\n", ultrasonic_distance / 58); // sprintf는 버퍼에 찍는 것
	}
}

void init_ultrasonic(void)
{
	// ---------------- left ----------------
	TRIG_DDR_LEFT |= 1 << TRIG_LEFT; // output mode로 설정
	ECHO_DDR_LEFT &= ~(1 << ECHO_LEFT); // input mode로 설정
	
	// 0 1 : 상승, 하강 edge에 둘 다 INT를 띄우도록 설정
	// INT0~3은 EICRA, INT4~7은 EICRB 레지스터
	EICRB |= 0 << ISC41 | 1 << ISC40; // INT4니까 EICRB에서 ISC41, 40
	
	// 16bit timer1을 설정해서 사용 16비트는 0~65535(0xffff)가 최대
	// 16Mhz를 1024로 분주 16000000/1024 --> 15625hz --> 15.625khz
	// 1주기 (1개의 펄스 소요시간) 1/15625 = 0.000064sec = 64us
	TCCR2 |=  1 << CS21 | 1 << CS20; // 1024로 분주
	EIMSK |= 1 << INT4; // 외부 인터럽트4번 (ECHO) 사용
	
	// ---------------- front ----------------
	TRIG_DDR_FRONT |= 1 << TRIG_FRONT; // output mode로 설정
	ECHO_DDR_FRONT &= ~(1 << ECHO_FRONT); // input mode로 설정
	
	// 0 1 : 상승, 하강 edge에 둘 다 INT를 띄우도록 설정
	// INT0~3은 EICRA, INT4~7은 EICRB 레지스터
	EICRB |= 0 << ISC51 | 1 << ISC50; // INT5니까 EICRB에서 ISC51, 50
	
	// 16bit timer1을 설정해서 사용 16비트는 0~65535(0xffff)가 최대
	// 16Mhz를 1024로 분주 16000000/1024 --> 15625hz --> 15.625khz
	// 1주기 (1개의 펄스 소요시간) 1/15625 = 0.000064sec = 64us
	TCCR2 |=  1 << CS21 | 1 << CS20; // 1024로 분주
	EIMSK |= 1 << INT5; // 외부 인터럽트5번 (ECHO) 사용
	
	// ---------------- right ----------------
	TRIG_DDR_RIGHT |= 1 << TRIG_RIGHT; // output mode로 설정
	ECHO_DDR_RIGHT &= ~(1 << ECHO_RIGHT); // input mode로 설정
	
	// 0 1 : 상승, 하강 edge에 둘 다 INT를 띄우도록 설정
	// INT0~3은 EICRA, INT4~7은 EICRB 레지스터
	EICRB |= 0 << ISC61 | 1 << ISC60; // INT6니까 EICRB에서 ISC61, 60
	
	// 16bit timer1을 설정해서 사용 16비트는 0~65535(0xffff)가 최대
	// 16Mhz를 1024로 분주 16000000/1024 --> 15625hz --> 15.625khz
	// 1주기 (1개의 펄스 소요시간) 1/15625 = 0.000064sec = 64us
	TCCR2 |=  1 << CS21 | 1 << CS20; // 1024로 분주
	EIMSK |= 1 << INT6; // 외부 인터럽트6번 (ECHO) 사용
}

void ultrasonic_trigger(void)
{
	TRIG_PORT_LEFT &= ~(1 << TRIG_LEFT);
	_delay_us(1);
	TRIG_PORT_LEFT |= (1 << TRIG_LEFT);
	_delay_us(15);
	TRIG_PORT_LEFT &= ~(1 << TRIG_LEFT);
	
	TRIG_PORT_FRONT &= ~(1 << TRIG_FRONT);
	_delay_us(1);
	TRIG_PORT_FRONT |= (1 << TRIG_FRONT);
	_delay_us(15);
	TRIG_PORT_FRONT &= ~(1 << TRIG_FRONT);
	
	TRIG_PORT_RIGHT &= ~(1 << TRIG_RIGHT);
	_delay_us(1);
	TRIG_PORT_RIGHT |= (1 << TRIG_RIGHT);
	_delay_us(15);
	TRIG_PORT_RIGHT &= ~(1 << TRIG_RIGHT);
}

//void distance_ultrasonic(void)
//{
	//if(ultrasonic_trigger_timer >= 500)
	//{
		//ultrasonic_trigger_timer = 0;
		//printf("%s\n%s\n%s\n",scm_L,scm_M,scm_R);
		//ultrasonic_trigger();
		//
	//}
//}
