﻿/*
 * ultrasonic.h
 *
 * Created: 2025-03-12 오후 2:49:06
 *  Author: microsoft
 */ 


#ifndef ULTRASONIC_H_
#define ULTRASONIC_H_

#define  F_CPU 16000000UL  // 16MHZ
#include <avr/io.h>
#include <util/delay.h>  // _delay_ms _delay_us
#include <avr/interrupt.h>
#include <stdio.h>   // printf scanf fgets등

#define US_TCNT_LEFT TCNT2 // timer3 16bit
#define TRIG_LEFT 0  // echo pin 번호
#define TRIG_PORT_LEFT PORTA
#define TRIG_DDR_LEFT DDRA

#define US_TCNT_LEFT TCNT2 // timer3 16bit
#define TRIG_FRONT 1  // echo pin 번호
#define TRIG_PORT_FRONT PORTA
#define TRIG_DDR_FRONT DDRA

#define US_TCNT_LEFT TCNT2 // timer3 16bit
#define TRIG_RIGHT 2  // echo pin 번호
#define TRIG_PORT_RIGHT PORTA
#define TRIG_DDR_RIGHT DDRA


#define ECHO_LEFT 4 // echo pin 번호
#define ECHO_PIN_LEFT PINE // External INT 4
#define ECHO_DDR_LEFT DDRE

#define ECHO_FRONT 5
#define ECHO_PIN_FRONT PINE
#define ECHO_DDR_FRONT DDRE

#define ECHO_RIGHT 6
#define ECHO_PIN_RIGHT PINE
#define ECHO_DDR_RIGHT DDRE



#endif /* ULTRASONIC_H_ */