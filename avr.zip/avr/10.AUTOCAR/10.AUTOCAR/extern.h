﻿/*
 * extern.h
 *
 * Created: 2025-03-19 오전 10:25:53
 *  Author: microsoft
 */ 


#ifndef EXTERN_H_
#define EXTERN_H_

extern void init_button(void);
extern int get_button(int button_num, int button_pin);

extern void init_uart0(void);
extern void UART0_transmit(uint8_t data);
extern void pc_command_processing(void);

extern void init_ultrasonic(void);
extern void distance_ultrasonic(void);

extern volatile uint8_t rx_message_received;

extern void init_timer1(void);
extern void init_L298N(void);

extern void stop(void);
extern void forward(int speed);
extern void backward(int speed);
extern void turn_left(int speed);
extern void turn_right(int speed);

extern void init_uart1(void);
extern volatile uint8_t bt_data;

extern void init_led(void);
extern void auto_mode_check(void);

extern int func_index;

extern volatile uint32_t msec_count;
extern volatile uint32_t sec_count;

extern void init_ultrasonic(void);
extern void ultrasonic_trigger(void);
extern void distance_check(void);

extern void init_fnd(void);
extern void fnd_forward_display(void);
extern void fnd_backward_display(void);
extern void fnd_left_display(void);
extern void fnd_right_display(void);

extern void I2C_LCD_init(void);
extern void I2C_LCD_Test(int *speed, int *current_mode);
extern void auto_start(void);

extern volatile int ultrasonic_left_distance;
extern volatile int ultrasonic_front_distance;
extern volatile int ultrasonic_right_distance;

extern int button_state;

extern volatile int ultrasonic_trigger_timer;

extern void init_speaker(void);

#endif /* EXTERN_H_ */