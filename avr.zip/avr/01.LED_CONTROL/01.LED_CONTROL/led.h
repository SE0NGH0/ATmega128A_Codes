﻿/*
 * led.h
 *
 * Created: 2025-03-05 오전 10:20:12
 *  Author: microsoft
 */ 


#ifndef LED_H_
#define LED_H_

#define F_CPU 16000000UL // 16MHZ Unsigned Long
#include <avr/io.h>
#include <util/delay.h> // _delay_ms, _delay_us 헤더파일

#endif /* LED_H_ */