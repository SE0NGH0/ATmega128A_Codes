/*
 * 01.LED_CONTROL.c
 *
 * Created: 2025-03-04 오후 4:25:29
 * Author : microsoft
 */ 

#define F_CPU 16000000UL // 16MHZ Unsigned Long
#include <avr/io.h>
#include <util/delay.h> // _delay_ms, _delay_us 헤더파일

#include "button.h"

extern int led_main(void); // 함수가 다른 파일에 들어있으면 extern으로 선언
extern void init_button(void); // 함수가 다른 파일에 들어있으면 extern으로 선언
extern int get_button(int button_num, int button_pin); // 함수가 다른 파일에 들어있으면 extern으로 선언
extern void led_all_on(void);
extern void led_all_off(void);
extern void shift_left_led_on(void);
extern void shift_right_led_on(void);
extern void shift_left_keep_ledon(void);
extern void shift_right_keep_ledon(void);
extern void flower_on(void);
extern void flower_off(void);

// none o/s 방식 또는 loop monitor 방식
int main(void)
{
	// led_main();
	int button0_state = 0; // 초기 상태를 0으로 출발
	// int button1_state = 0;
	// int button2_state = 0;
	// int button3_state = 0;
	
	void (*fp[]) (void) =
	{
		led_all_off,
		led_all_on,
		shift_left_led_on,
		shift_right_led_on,
		shift_left_keep_ledon,
		shift_right_keep_ledon,
		flower_on,
		flower_off
	};
	
	init_button();
		   //76543210
	DDRA = 0b11111111; // PORTA를 출력 모드(1)로 설정
	      // ---- 상위 nibble : 상위 4bits
		  //     ---- 하위 nibble : 하위 4bits
					   // DDR(Data Direction Register) : 방향 설정
					   // 1 : 출력, 0 : 입력을 의미
					   // 0b : 2진수
					   // 0x : hex
					   // DDRA = 0Xff;
	// int count = 0;
#if 0 // switch~case 1 BUTTON
	while(1)
	{
		/*
		if(get_button(BUTTON0, BUTTON0PIN))
		{
			button0_state = !button0_state;
			count += 1;
			switch(count)
			{
				case 1: led_all_on(); break;
				case 2: led_all_off(); break;
				case 3: shift_left_led_on(); break;
				case 4: shift_right_led_on(); break;
				case 5: shift_left_keep_ledon(); break;
				case 6: shift_right_keep_ledon(); break;
				case 7: flower_on(); break;
				case 8: flower_off(); count = 0; break;
			}
		}
		*/
		if(get_button(BUTTON0, BUTTON0PIN))
		{
			button0_state++;
			button0_state %= 8;
		}
		switch(button0_state)
		{
			case 0: led_all_off(); break;
			case 1: led_all_on(); break;
			case 2: shift_left_led_on(); break;
			case 3: shift_right_led_on(); break;
			case 4: shift_left_keep_ledon(); break;
			case 5: shift_right_keep_ledon(); break;
			case 6: flower_on(); break;
			case 7: flower_off(); break;
		}
	}
#endif

#if 1 // 함수 포인터 배열 1 BUTTON
	while(1)
	{
		if(get_button(BUTTON0, BUTTON0PIN))
		{
			button0_state++;
			button0_state %= 8;
		}
		fp[button0_state] ();
	}
#endif

#if 0 // org 4 BUTTON
	while (1)   // for(;;)
	{
		// 1 button 처리 (toggle)
		// button0를 1번 누르면 led_all_on
		//			 1번 다시 누르면 led_all_off
		if (get_button(BUTTON0, BUTTON0PIN))
		{
			button0_state = !button0_state; // 반전 0 <--> 1
			if(button0_state)
			{
				led_all_on();
			}
			else
			{
				led_all_off();
			}
		}
		if (get_button(BUTTON1, BUTTON1PIN))
		{
			button1_state = !button1_state; // 반전 0 <--> 1
			if(button1_state)
			{
				shift_left_led_on();
			}
			else
			{
				shift_right_led_on();
			}
		}
		if (get_button(BUTTON2, BUTTON2PIN))
		{
			button2_state = !button2_state; // 반전 0 <--> 1
			if(button2_state)
			{
				shift_left_keep_ledon();
			}
			else
			{
				shift_right_keep_ledon();
			}
		}
		if (get_button(BUTTON3, BUTTON3PIN))
		{
			button3_state = !button3_state; // 반전 0 <--> 1
			if(button3_state)
			{
				flower_on();
			}
			else
			{
				flower_off();
			}
		}
	}
	
#endif
}