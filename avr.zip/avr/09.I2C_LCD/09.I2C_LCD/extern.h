﻿/*
 * extern.h
 *
 * Created: 2025-03-19 오전 10:25:53
 *  Author: microsoft
 */ 


#ifndef EXTERN_H_
#define EXTERN_H_

extern int led_main(void);   // 선언
extern void init_button(void);
extern int get_button(int button_num, int button_pin);

extern void led_all_on(void);
extern void led_all_off(void);
extern void shift_left_ledon(void);
extern void shift_right_ledon(void);
extern void shift_left_keep_ledon(void);
extern void shift_right_keep_ledon(void);
extern void flower_on(void);
extern void flower_off(void);
extern int fnd_main(void);

extern void init_uart0(void);
extern void UART0_transmit(uint8_t data);
extern void pc_command_processing(void);

extern void init_ultrasonic(void);
extern void distance_ultrasonic(void);

extern int led_state;
extern void (*funcs[])(void);
extern volatile uint8_t rx_message_received;

extern void dht11_main(void);
extern void I2C_LCD_Test(void);



#endif /* EXTERN_H_ */