﻿/*
 * def.h
 *
 * Created: 2025-03-10 오후 3:05:46
 *  Author: microsoft
 */ 


#ifndef DEF_H_
#define DEF_H_


#define COMMAND_NUMBER 10 // command 개수
#define COMMAND_LENGTH 40 // command 길이


#endif /* DEF_H_ */