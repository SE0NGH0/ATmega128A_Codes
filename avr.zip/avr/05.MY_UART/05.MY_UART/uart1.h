﻿/*
 * uart1.h
 *
 * Created: 2025-03-11 오후 4:35:26
 *  Author: microsoft
 */ 


#ifndef UART1_H_
#define UART1_H_

#define F_CPU 16000000L
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h> // sei()
#include "def.h"

// led_all_on\n
// led_all_off\n
volatile uint8_t rx1_buff[COMMAND_NUMBER][COMMAND_LENGTH]; // uart0로부터 들어온 문자를 저장하는 버퍼(변수)
volatile int rear1 = 0; // input index : USART1_RX_vect에서 집어 넣어주는 index
volatile int front1 = 0; // output index


#endif /* UART1_H_ */