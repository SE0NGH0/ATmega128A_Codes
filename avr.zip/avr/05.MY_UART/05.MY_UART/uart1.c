﻿/*
 * uart1.c
 *
 * Created: 2025-03-11 오후 4:35:37
 *  Author: microsoft
 */ 
#include "uart1.h"
#include <string.h> // strcpy, strncmp, strcmp 등

void init_uart1(void);
void UART1_transmit(uint8_t data);
void bt_command_processing(void);

#define FUNC_NUMBER 8

extern void (*fp[FUNC_NUMBER]) (void);

/*
	PC comportmaster로부터 1byte가 들어올 때마다 이곳으로 들어온다. (RX INT)
	예) led_all_on\n ==> 11번 이곳으로 들어온다.
		led_all_off\n
*/

volatile uint8_t rx1_msg_received = 0;

ISR(USART1_RX_vect)
{
	volatile uint8_t rx1_data;
	volatile static int i = 0;
	
	rx1_data = UDR1; // uart0의 H/W register(UDR0)로부터 1byte를 읽어들인다.
					// rx_data = UDR0;를 실행하면 UDR0의 내용이 빈다. (empty)
	if(rx1_data == '\n')
	{
		rx1_buff[rear1++][i] = '\0';
		rear1 %= COMMAND_NUMBER; // 0~9
		i = 0; // 다음 string을 저장하기 위한 1차원 index값을 0으로
		// !!!! rx_buff queue full check하는 logic 추가
	}
	else
	{
		rx1_buff[rear1][i++] = rx1_data;
		// COMMAND_LENGTH를 check하는 logic 추가
		
	}
}

/*
	1. 전송 속도 : 9600bps : 총 글자수 : 9600/10bit ==> 960자
		(1글자를 송, 수신하는 데 소요 시간 : 약 1ms)
	2. 비동기 방식(start/stop 부호 비트로 데이터를 구분
	3. RX(수신) : 인터럽트 방식으로 구현 (TX는 폴링 방식으로 구현)
*/

void init_uart1(void)
 {
	// 1. 9600bps로 설정
	UBRR1H = 0x00;
	UBRR1L = 207; // 9600bps
	// 2. 2배속 통신
	UCSR1A |= 1 << U2X1; // 2배속 통신
	UCSR1C |= 0x06; // 비동기 / data8bits / none parity
	
	// RXEN1 : UART1로부터 수신이 가능하도록
	// TXEN1 : UART1로부터 송신이 가능하도록
	// RXCIE1 : UART1로부터 1byte가 들어오면 (stop bit가 들어오면) rx interrupt를 발생시켜라
	UCSR1B |= 1 << RXEN1 | 1 << TXEN1 | 1 << RXCIE1;
}

// UART0로 1byte를 전송하는 함수 (polling 방식)
void UART1_transmit(uint8_t data)
{
	// 데이터 전송 중이면 전송이 끝날 때까지 기다린다.
	while(!(UCSR1A & 1 << UDRE1))
		; // no operation
	UDR1 = data; // data를 H/W 전송 register에 쏜다.
}

void bt_command_processing(void)
{
	if(front1 != rear1) // rx_buff에 data가 존재
	{
		printf("%s\n", rx1_buff[front1]); // &rx_buff[front][0]와 동일
		if(strncmp(rx1_buff[front1], "led_all_on", strlen("led_all_on")) == NULL)
		{
			fp[0]();
		}
		else if(strncmp(rx1_buff[front1], "led_all_off", strlen("led_all_off")) == NULL)
		{
			fp[1]();
		}
		else if(strncmp(rx1_buff[front1], "shift_left_ledon", strlen("shift_left_ledon")) == NULL)
		{
			while(1)
			{
				fp[2]();
				if(UCSR1A & 1 << RXC1)
				break;
			}                                    
		}
		else if(strncmp(rx1_buff[front1], "shift_right_ledon", strlen("shift_right_ledon")) == NULL)
		{
			while(1)
			{
				fp[3]();
				if(UCSR1A & 1 << RXC1)
				break;
			}
		}
		else if(strncmp(rx1_buff[front1], "shift_left_keep_ledon", strlen("shift_left_keep_ledon")) == NULL)
		{
			while(1)
			{
				fp[4]();
				if(UCSR1A & 1 << RXC1)
				break;
			}
		}
		else if(strncmp(rx1_buff[front1], "shift_right_keep_ledon", strlen("shift_right_keep_ledon")) == NULL)
		{
			while(1)
			{
				fp[5]();
				if(UCSR1A & 1 << RXC1)
				break;
			}
		}
		else if(strncmp(rx1_buff[front1], "flower_on", strlen("flower_on")) == NULL)
		{
			while(1)
			{
				fp[6]();
				if(UCSR1A & 1 << RXC1)
				break;
			}
		}
		else if(strncmp(rx1_buff[front1], "flower_off", strlen("flower_off")) == NULL)
		{
			while(1)
			{
				fp[7]();
				if(UCSR1A & 1 << RXC1)
				break;
			}
		}
		front1++;
		front1 %= COMMAND_NUMBER;
		// !!!! queue full check하는 logic들어가야 한다. !!!!
	}
}