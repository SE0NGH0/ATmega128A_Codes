﻿/*
 * led.c
 *
 * Created: 2025-03-05 오전 10:21:53
 *  Author: microsoft
 */ 

#include "led.h"
#include "button.h"

int led_main(void);   // 선언
void led_all_on(void);
void led_all_off(void);
void shift_left_ledon(void);
void shift_right_ledon(void);
void shift_left_keep_ledon(void);
void shift_right_keep_ledon(void);
void flower_on(void);
void flower_off(void);
void state_transition(void);

extern void init_button(void);
extern int get_button(int button_num, int button_pin);

extern volatile int msec_count;
#define FUNC_NUMBER 8

int state = 0;
int button0_state = 0;
int button1_state = 0;

void (*fp[]) (void)= 
{
	led_all_on,
	led_all_off,
	shift_left_ledon,
	shift_right_ledon,
	shift_left_keep_ledon,  // _delay_ms(200)
	shift_right_keep_ledon,
	flower_on,
	flower_off
};

int led_main(void)   // 정의 
{
	DDRA = 0xff;   // PORTA에 연결된 pin8개를 output mode로 
	init_button();

#if 1
	while(1)
	{
		if (get_button(BUTTON0, BUTTON0PIN))
		{
			button0_state = !button0_state;
		}
		if (get_button(BUTTON1, BUTTON1PIN))
		{
			button1_state++;
			button1_state %= FUNC_NUMBER;
		}
		
		fp[state]();
		
	}
#else
	while(1) 
	{
		shift_left_ledon();
		shift_right_ledon();
		shift_left_keep_ledon();  // _delay_ms(200)
		shift_right_keep_ledon();
		flower_on(); 
		flower_off();
	}	
#endif
}

void shift_left_ledon(void)
{
#if 1
	// (1) for문 제거 (2) _delay_ms(30) 제거
	static int i = 0;
	
	if(msec_count >= 100)
	{
		msec_count = 0;
		if(i >= 8)
		{
			i = 0;
			PORTA = 0;
			state_transition();
			
		}
		else
		{
			PORTA = 0b00000001 << i++; // (1) PORTA = 0b00000001 << i (2) i++
		}
	}
#else // org
	for (int i=0; i < 8; i++)
	{
		PORTA = 0b00000001 << i;
		//               1 i=0;
	    //        00000010 i=1;
	    //        10000000 i=7;
		_delay_ms(30);
	}	
#endif
}

void shift_right_ledon(void)
{
#if 1
	static int i = 0;
	
	if(msec_count >= 100)
	{
		msec_count = 0;
		if(i >= 8)
		{
			i = 0;
			PORTA = 0;
			state_transition();
		}
		else
		{
			PORTA = 0b10000000 >> i++;
		}
	}
#else
	PORTA=0;
	for (int i=0; i < 8; i++)
	{
		PORTA = 0b10000000 >> i;
		//        10000000 i=0;
		//        01000000 i=1;
		_delay_ms(30);
	}
#endif
}

void shift_left_keep_ledon(void)
{
#if 1
	static int i = 0;
	
	if(msec_count >= 100)
	{
		msec_count = 0;
		if(i >= 8)
		{
			i = 0;
			PORTA = 0;
			state_transition();
		}
		else
		{
			PORTA |= 0b00000001 << i;
			i++;
		}
	}
#else
	for (int i=0; i < 8; i++)
	{
		PORTA |= 0b00000001 << i;
		//               1 i=0;
		//        00000010 i=1;
		//        10000000 i=7;
		_delay_ms(30);
	}
#endif
}

void shift_right_keep_ledon(void)
{
#if 1
	static int i = 0;
	
	if(msec_count >= 100)
	{
		msec_count = 0;
		if(i >= 8)
		{
			i = 0;
			PORTA = 0;
			state_transition();
		}
		else
		{
			PORTA |= 0b10000000 >> i;
			i++;
		}
	}
#else
	PORTA=0;
	for (int i=0; i < 8; i++)
	{
		PORTA |= 0b10000000 >> i;
		//        10000000 i=0;
		//        01000000 i=1;
		_delay_ms(30);
	}
#endif
}

void flower_on(void)
{
#if 1
	// (1) for문 제거 (2) _delay_ms(30) 제거
	static int i = 0;

	if(msec_count >= 100)
	{
		msec_count = 0;
		if(i >= 4)
		{
			i = 0;
			PORTA = 0;
			state_transition();
		}
		else
		{
			PORTA |= 0x10 << i | 0x08 >> i;
			i++;
		}
	}
#else
	PORTA=0;
	for (int i=0; i < 4; i++)
	{
		PORTA |= 0x10 << i | 0x08 >> i;
		_delay_ms(30);
	}
#endif
}

void flower_off(void)
{
#if 1
	unsigned char h=0xf0;
	unsigned char l=0x0f;
	static int i = 0;

	if(msec_count >= 100)
	{
		msec_count = 0;
		if(i >= 4)
		{
			i = 0;
			PORTA = 0;
			state_transition();
		}
		else
		{
			PORTA = (h >> i) & 0xf0 | (l << i) & 0x0f;
			i++;
		}
	}
#else
	unsigned char h=0xf0;
	unsigned char l=0x0f;
	
	PORTA=0;
	for (int i=0; i < 4; i++)
	{
		PORTA = (h >> i) & 0xf0 | (l << i) & 0x0f;
		_delay_ms(30);
	}
	PORTA=0;
	_delay_ms(30);
#endif
}

void led_all_on(void)
{
	PORTA = 0xff;
}

void led_all_off(void)
{
	PORTA = 0x00;
}

void state_transition(void)
{
	if(!button0_state)
	{
		state++;
		state = state % FUNC_NUMBER;
	}
	else
	{
		state = button1_state;
	}
}