﻿/*
 * ultrasonic.c
 *
 * Created: 2025-03-12 오후 2:49:17
 *  Author: microsoft
 */ 

#include "ultrasonic.h"
#include "fnd.h"

extern volatile int ultrasonic_check_timer;

void init_ultrasonic();
void trigger_ultrasonic();
void distance_ultrasonic();
void sonic_led(void);
void sonic_fnd(void);

volatile int ultrasonic_dis = 0;
volatile int ultrasonic_cm = 0;
volatile char scm[50];

// PE4 : 외부 INT4 초음파 센서의 상승, 하강 에지 둘다 INT가 ISR(INT4_vect)로 들어온다.
// 결국 2번 (상승 : 1번, 하강 : 1번) 들어온다.
ISR(INT4_vect)
{
	// 1. 상승에지
	if(ECHO_PIN & 1 << ECHO)
	{
		TCNT1 = 0;
	}
	else // 2. 하강에지
	{
		// ECHO 핀에 들어온 펄스 개수를 US로 환산
		ultrasonic_dis = 1000000.0 * TCNT1 * 1024 / F_CPU;
		// 예) TCINT에 10이 들어 있다고 가정하자
		// 15.625KHz의 1주기 64us이다.
		// 0.000064sec(64us) * 10 ==> 0.00064sec(640us)
		// 640us / 58us(1cm 이동하는데 소요시간) ==> 11 cm이다.
		// --- 1cm : 58us
		ultrasonic_cm = ultrasonic_dis / 58;
		sprintf(scm, "dis: %dcm\n", ultrasonic_cm); // cm 환산
	}
}

void init_ultrasonic(void)
{
	TRIG_DDR |= 1 << TRIG; // 출력 모드로 설정
	ECHO_DDR &= ~(1 << TRIG); // 입력 모드로 설정 ECHO_DDR &= 0b11110111;
	// 0 1 : 상승에지(rising edge)와 하강에지(falling edge) 둘다 INT를 띄우도록 요청
	EICRB |= 0 << ISC41 | 1 << ISC40;
	// 16bit timer1번을 설정해서 사용 65535(max) : 0xffff
	// 16MHz를 1024로 분주 16000000Hz/1024 --> 15625Hz --> 15.625KHz
	// 1주기 T(주기) = 1/f = 1/15625 ==> 0.000064sec ==> 64us
	TCCR1B |= 1 << CS12 | 1 << CS10; // 1024로 분주
	EIMSK |= 1 << INT4; // EXTERNAL INT4 (ECHO 핀)
}

void trigger_ultrasonic(void)
{
	TRIG_PORT &= ~(1 << TRIG); // low
	_delay_us(1);
	TRIG_PORT |= 1 << TRIG; // high
	_delay_us(15); // 규격에는 10us인데 여유를 둬서 15us로 설정
	TRIG_PORT &= ~(1 << TRIG); // low
	
}

void distance_ultrasonic(void)
{
	
	if(ultrasonic_check_timer >= 1000) // 1초 체크
	{
		ultrasonic_check_timer = 0;
		printf("%s", scm);
			
		trigger_ultrasonic();
	}
}

void sonic_led(void)
{
	DDRA = 0xff;
	PORTA = 0x00;
	 
	if(ultrasonic_cm >= 1 && ultrasonic_cm < 3)
		PORTA = 0x01;
	if(ultrasonic_cm >= 3 && ultrasonic_cm < 6)
		PORTA = 0x03;
	if(ultrasonic_cm >= 6 && ultrasonic_cm < 9)
		PORTA = 0x07;
	if(ultrasonic_cm >= 9 && ultrasonic_cm < 12)
		PORTA = 0x0f;
	if(ultrasonic_cm >= 12 && ultrasonic_cm < 14)
		PORTA = 0x1f;
	if(ultrasonic_cm >= 14 && ultrasonic_cm < 16)
		PORTA = 0x3f;
	if(ultrasonic_cm >= 16 && ultrasonic_cm < 18)
		PORTA = 0x7f;
	if(ultrasonic_cm >= 18)
		PORTA = 0xff;
}

void sonic_fnd(void)
{
	uint8_t fnd_font[] = {~0xc0,~0xf9,~0xa4,~0xb0,~0x99,~0x92,~0x82,~0xd8,~0x80,~0x90,~0x7f};
		
	int fnd_number=ultrasonic_cm;
	
	int f0=fnd_number/1000; //천의 자리 숫자 0~9;
	int f1=(fnd_number/100) % 10; //백의 자리
	int f2=(fnd_number/10) % 10; //십의 자리
	int f3=(fnd_number) % 10; //일의자리
	
	static int digit_select=0;
	FND_DATA_PORT=0x00;
	
	switch(digit_select)
	{
		case 0: // FND 첫번째칸
			FND_DIGIT_PORT=~0x10;
			FND_DATA_PORT = fnd_font[f0];
			break;
		case 1: // FND 두번째칸
			FND_DIGIT_PORT=~0x20;
			FND_DATA_PORT = fnd_font[f1];
			break;
		case 2: // FND 세번째칸
			FND_DIGIT_PORT=~0x40;
			FND_DATA_PORT =fnd_font[f2];
			break;
		case 3: // FND 네번째칸
			FND_DIGIT_PORT=~0x80;
			FND_DATA_PORT=fnd_font[f3];
			break;
	}
	digit_select ++;
	digit_select %=4;
}